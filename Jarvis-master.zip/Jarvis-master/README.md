# Jarvis
This is Python Desktop Assistant. It can perform mulitiple tasks by just recognizing your voice commands.
To make this run in your pc/laptop you need to download few dependencies:
  1. pyttsx3
  2. SpeechRecognition
  3. Pyaudio
  4. Roman
  5. OpenCV 
  
  use pip install to download these dependencies
  
  Also you need to separately download .whl file of pyaudio from uci python and then install it in your package folder
Also made a couple of changes in this code

Guys! Also remember to have a fast and secured internet connection to make this run. Because it is using google speech recognition api to understand the commands.

Also, guys if you want contribute in this project and wants to add more features into it, give me suggestions in the comment box or email to me at mridul27gupta@gmail.com. 

Here is my Linkedin Profile: https://www.linkedin.com/in/mridulcse27/
